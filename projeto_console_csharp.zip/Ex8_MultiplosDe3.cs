using System;

class Ex8_MultiplosDe3
{
    public void Executar()
    {
        for (int i = 0; i <= 10; i++)
            if (i % 3 == 0)
                Console.WriteLine(i);
    }
}